package com.example.samy.myapplication;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by samy R on 16/06/2015.
 */


public class TCActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tc);
    }

}

